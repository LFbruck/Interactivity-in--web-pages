let imagem = document.querySelector("img");
imagem.addEventListener("click", function () {
  imagem.setAttribute("src", "cafe.png");
});
